
function sendMessage(){

const input=document.getElementById("messageInput")
const text=input.value

const box=document.getElementById("chatBox")

const msg=document.createElement("div")
msg.className="message sent"
msg.innerText=text

box.appendChild(msg)

input.value=""

}
